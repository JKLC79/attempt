package com.example.shenyang;

import android.Manifest;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.esri.arcgisruntime.ArcGISRuntimeEnvironment;
import com.esri.arcgisruntime.arcgisservices.ArcGISMapServiceInfo;
import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.layers.ArcGISMapImageLayer;
import com.esri.arcgisruntime.loadable.LoadStatus;
import com.esri.arcgisruntime.location.LocationDataSource;
import com.esri.arcgisruntime.mapping.ArcGISMap;
import com.esri.arcgisruntime.mapping.Basemap;
import com.esri.arcgisruntime.mapping.view.LocationDisplay;
import com.esri.arcgisruntime.mapping.view.MapView;

import java.util.List;

import util.PermissionUtils;

import static com.example.shenyang.R.layout.activity_main;

public class MainActivity extends AppCompatActivity implements PermissionUtils.PermissionCallbacks {
private MapView mMapView;
private Button button_search;
private Button button_site;
private Button button_delete;
private ImageView start;

private static final int REQUEST_PERMISSION_CODE = 0;
private LocationDisplay mLocationDisplay;
    private String[] permissions = {
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
    };

     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate (savedInstanceState);
        setContentView (activity_main);

         mMapView = findViewById (R.id.mapview);
         setupMap ();


         //去水印
         ArcGISRuntimeEnvironment.setLicense ("runtimelite,1000,rud1061423001,none,7RE60RFLTF0KC2EN0186");
         //去logo
         mMapView.setAttributionTextVisible (false);

         //向地图添加在线图层(map服务)
         //创建处理动态生成的地图图像的MapImageLayer
         String url = "http://218.60.146.66:6080/arcgis/rest/services/辽宁保护区GCS/MapServer";
         String mainArcGISMapImageLayerURL= "http://218.60.146.66:6080/arcgis/rest/services/辽宁地形图GCS/MapServer";
         final ArcGISMapImageLayer mapImageLayer = new ArcGISMapImageLayer (mainArcGISMapImageLayerURL);
         final ArcGISMapImageLayer mapImageLayer1 = new ArcGISMapImageLayer (url);

         mapImageLayer.addDoneLoadingListener (new Runnable () {
             @Override
             public void run() {
                 if(mapImageLayer.getLoadStatus ()== LoadStatus.LOADED){
                     ArcGISMapServiceInfo mapServiceInfo = mapImageLayer.getMapServiceInfo ();
                     //在这里使用地图信息(mapServiceInfo)是要素信息
                 }
             }
         });
         mapImageLayer1.addDoneLoadingListener (new Runnable () {
             @Override
             public void run() {
                 if(mapImageLayer1.getLoadStatus ()== LoadStatus.LOADED){
                     ArcGISMapServiceInfo mapServiceInfo = mapImageLayer.getMapServiceInfo ();
                 }
             }
         });
         //获取地图实例
         ArcGISMap map = mMapView.getMap ();
         //添加地图图像作为操作层
         map.getOperationalLayers ().add (mapImageLayer);
         map.getOperationalLayers ().add (mapImageLayer1);
         mMapView.setMap (map);



     }
//定义地图，并初始化ArcGISMap（map）
    private void setupMap() {
        if (mMapView != null) {
            Basemap.Type basemapType = Basemap.Type.TOPOGRAPHIC;
            double latitude = 42.389842773504364;
            double longitude = 122.89148214747294;
            int levelOfDetail = 11;
            ArcGISMap map = new ArcGISMap (basemapType, latitude, longitude, levelOfDetail);

            mMapView.setMap (map);

            //获取定位权限
            if (PermissionUtils.hasPermissions (this, permissions)) {
                startLocation ();
            } else {
                PermissionUtils.requestPermissions (this, REQUEST_PERMISSION_CODE, permissions);

            }
        }
    }
   @Override
    public void onRequestPermissionsResult(int requestCode,@NonNull String[] permissions,@NonNull int[] grantResults){
            super.onRequestPermissionsResult (requestCode,permissions,grantResults);
            PermissionUtils.onRequestPermissionsResult (requestCode,permissions,grantResults,this);

        }

    private void startLocation( ){


        mLocationDisplay = mMapView.getLocationDisplay();
        mLocationDisplay.setAutoPanMode(LocationDisplay.AutoPanMode.RECENTER);
        //当我们执行LocationDisplay.startAsync()方法时候，会在地图上显示出我们当前位置
        mLocationDisplay.startAsync();


        //获取的点是基于当前地图坐标系的点
        Point point = mLocationDisplay.getMapLocation();
        Log.e("xyh", "point: " + point.toString());
        //获取基于GPS的位置信息
        LocationDataSource.Location location = mLocationDisplay.getLocation ();
        //获取基于WGS84的经纬度坐标
        Point point1 = location.getPosition ();
        if(point1 != null){
            Log.e ("xyh","point1"+point1.toString ());
        }

        //如果要在LocationDisplay里进行位置信息的自动监听，方法也很简单，只需要LocationDisplay.addLocationChangedListener即可
        mLocationDisplay.addLocationChangedListener(new LocationDisplay.LocationChangedListener() {
            @Override
            public void onLocationChanged(LocationDisplay.LocationChangedEvent locationChangedEvent) {
                LocationDataSource.Location location = locationChangedEvent.getLocation();
                Log.e("xyh", "onLocationChanged: " + location.getPosition().toString());
            }
        });
    }
    @Override
    public void onPermissionsAllGranted(int requestCode, List<String> perms, boolean isAllGranted) {
        if(isAllGranted){
            startLocation ();
        }
    }

    @Override
    public void onPermissionsDenied(int requestCode, List<String> perms) {

    }


    @Override
    protected void onPause() {
        if (mMapView != null) {
            mMapView.pause();
        }
        super.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mMapView != null) {
            mMapView.resume();
        }
    }

    @Override
    protected void onDestroy() {
        if (mMapView != null) {
            mMapView.dispose();
        }
        super.onDestroy();
    }


}
